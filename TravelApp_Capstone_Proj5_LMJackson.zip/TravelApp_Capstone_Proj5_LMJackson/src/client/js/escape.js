//Global Variables setup//

/* Web API Data*/
const geonamesURL = 'http://api.geonames.org/searchJSON?formatted=true';
const userName = 'lj1956';
const pixabayURL = 'http://pixabay.com/api/?key=';
const weatherbitCurrentURL = 'http://api.weatherbit.io/v2.0/current?';
const weatherbitFutureURL = 'http://api.weatherbit.io/v2/forecast/daily?';
const weatherbitKEY = 'c690f3644d3243fc8a7f966147bebbfc';
const pixabayKEY = '18063077-03d6b978fe1a49afb960fad7b';

const PREDICT = { 
    "CURRENT" : "current",
    "FUTURE" : "future",
};
//DOM interactions//

function getTravelCity() {
    
    return document.getElementById('city').value;
}

function getTravelDate() {
    
    const dateString = document.getElementById('departure-date').value.split('-');
    
    return dateString.join('/');
}

function getCountdown (travelDate) {

    const currentDate = new Date();
    const myTravelDate = new Date(travelDate);

    const calcTime = Math.abs(myTravelDate - currentDate);
    const calcDiff = Math.ceil(calcTime / (1000 * 60 * 60 *24));

    return calcDiff;
}

//Add API Calls//
async function fetchLocation(city) {
    
    const endPoint = `${geonamesURL}&q=${city}&username=${userName}&style=${'full'}`;
    
    try {

        const apiResponse = await fetch(endPoint);
        
        if (!apiResponse.ok) {
            return null;
        }           

        const location = {};
        const responseBody = await apiResponse.json();

        location.latitude = responseBody.geonames[0].lat;
        location.longitude = responseBody.geonames[0].lng;
        location.countryName = responseBody.geonames[0].countryName;

        console.log(location);
        return location;
    }
    catch (error) {
        console.log("Error: " + error);
    };
}

async function fetchWeather(latitude, longitude, forecast = PREDICT.CURRENT) {

    const baseUrl = (forecast === PREDICT.CURRENT) ? `${weatherbitCurrentURL}` : `${weatherbitFutureURL}`;

    const endPoint = `${baseUrl}&lat=${latitude}&lng=${longitude}&key=${weatherbitKEY}`;

    try {

        const apiResponse = await fetch(endPoint);

        const forecast = {};

        const responseBody = await apiResponse.json();

        forecast.temperature = responseBody.fetchWeather[0].temp;
        forecast.weather = responseBody.fetchWeather[0].weather;

        return forecast;
    }
    catch (error) {
        console.log("error fetching weather prediction forecast: " + error);
    };
}

async function fetchPhoto(city, country) {
    const endPoint = `${pixabayURL}&q=${city}&key=${pixabayKEY}&image_type=${pixabayURL.image_type}`;

    try {

        const apiResponse = await fetch(endPoint);

        //return the following if no response from image req//
        if (!apiResponse.ok){
            return null;
        }
        
        const responseBody = await apiResponse.json();

        //return the following if city images are found per user req//
        if (responseBody.hits !== 0) {
            return responseBody.hits[0].largeImageURL;
        }

        //else, fetch and return images for the country per user req//
        endPoint = `${pixabayURL}&q=${country}&key=${pixabayURL.pixabayKEY}&image_type=${pixabayURL.image_type}`;

        const countryImageRes = await fetch(endPoint);

        //return the following if no response from country req//
        if(!countryImageRes.ok) {
            return null;
        }
        
        const countryImageReturn = await countryImageRes.json();

        return countryImageReturn.hits[0].largeImageURL;

    }
    catch (error) {
        console.log("error while fetching country photo: " + error);
    };
}

export {
    getTravelCity,
    getTravelDate,
    fetchLocation,
    fetchWeather,
    fetchPhoto,
    getCountdown,
    PREDICT,
}