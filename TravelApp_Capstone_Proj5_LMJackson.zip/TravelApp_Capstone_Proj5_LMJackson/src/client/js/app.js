import {
    getTravelCity,
    getTravelDate,
    fetchLocation,
    fetchWeather,
    fetchPhoto,
    getCountdown,
    PREDICT
}   from "./escape";

import fetch from "node-fetch";

//Establish global variable//

const travelTo = {};

let myTrips = [];

let submitButton = document.getElementById('tripButton');
if (tripButton) {
    submitButton.addEventListener('click' , handleSubmit);
};

//Establish helper functions//
//Generate List element//
const createList = (travel, index) => {
    const newList = (document.createElement)("li");
    newList.setAttribute("class", "card-content");

    //Generate Span element//
    const newSpan = document.createElement("span");
    const imageElement = document.createElement("img");
    imageElement.setAttribute("id" , index);
    imageElement.setAttribute("src" , travel.photoUrl);
    imageElement.setAttribute("alt" , "city photo");
    newSpan.appendChild(imageElement);

//Generate Divs for page layout//
    const newDiv = document.createElement("div");
    
    const travelHeading = document.createElement("h3");
    travelHeading.setAttribute("id" , "travel-city");
    travelHeading.innerHTML = `${travel.city}, ${travel.location.country}`;

    const travelWeather = document.createElement("p");
    travelWeather.setAttribute("id" , "weather");
    travelWeather.innerHTML = `${travel.weatherForecast.temperature} &deg;C - ${travel.weatherForecast.description}`;

    const travelCountdown = document.createElement("p");
    travelCountdown.setAttribute("id" , "travel-countdown");
    travelCountdown.innerHTML = `Your escape is ${travel.countdown} days away`;

    newDiv.appendChild(travelHeading);
    newDiv.appendChild(travelWeather);
    newDiv.appendChild(travelCountdown);

    
    //Generate addition of span and div to list //
    newList.appendChild(newSpan);
    newList.appendChild(newDiv);

    return newList;
};

const renderNewElement = (travel, index) => {
    const li = createList(travel, index);
    return li;
};

const renderAllElements = (travels) => {
    return travels.map((travel, index) => {
        return createList(travel, index);
    });
};

    const travelHolder = document.getElementById('travel-holder');
    let travelsNode = document.getElementById("travels").value;


function updateUI(myTrips) {
    if (!myTrips) {
        alert("No saved trips found. Please try again");
        return;
    }
    const length = myTrips.length;
    if (length == 0) {
        travelHolder.style.visibility = 'block';
    }
        
    if (travelsNode.childElementCount > 0) {
        const newList = renderNewElement(myTrips[length - 1], length - 1);
        travelsNode.appendChild(newList);
    } else {
        const travelCards = renderAllElements(myTrips);

        travelCards.forEach((card) => {
            travelsNode.appendChild(card);
        });
    }
    // hide message in holder//
    travelHolder.style.visibility = 'hidden';
}

function updateSearchResult(travelTo) {
    const travelCityElement = document.getElementById("travel-city");
    const weatherElement = document.getElementById("weather");
    const travelCountryElement = document.getElementById("travel-country");
    const travelCountdownElement = document.getElementById("travel-countdown");
    const imageElement = document.getElementById("travel-image");

    travelCityElement.innerHTML = travelTo.city;
    weatherElement.innerHTML = `${weatherForecast.temperature} &deg; C `;
    travelCountryElement.innerHTML = travelTo.country;
    travelCountdownElement.innerHTML = `Your Escape is ${travelTo.countdown} days away`;
    imageElement.setAttribute("src", travelTo.photoUrl);

    //hide holder//
    document.getElementById("search-return").classList.remove("display-result");
}
  
//Return Travel requested//

async function handleSubmit(e) {
    e.preventDefault();

    travelTo.city = getTravelCity();
    travelTo.travelDate = getTravelDate();

    if (!travelTo.city || !travelTo.travelDate) {
        alert("City and Travel Date are required!");
        return;
    }

    //get countdown to travel date//
    travelTo.countdown = getCountdown(travelTo.travelDate);

    //Fetch location from geonames//
   
    travelTo.location = await fetchLocation(travelTo.city);

    if (travelTo.location === null) {
        alert("error fetching location");
        return;
    }

    //Fetch weather from weatherbit//

    travelTo.weather = await fetchWeather(
    travelTo.location.latitude,
    travelTo.location.longitude,
    );

    // Fetch the location photo from pixabay//
    travelTo.photoUrl = await fetchPhoto(
        travelTo.city,
        travelTo.location.countryName,
    );
    
    console.log(travelTo);
    updateSearchResult(travelTo);
}
//save trip info
async function handleSave(e) {
    e.preventDefault();

    try {
        const response = await fetch("http://localhost:8000/travels/save", {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json;charset=UTF-8",
             },
             body: JSON.stringify({ travel: travelTo }),
            });
            
            if (!response.ok) {
                return null;
            }

            myTrips = await response.json();

            removeSearchResult();
            updateUI(myTrips);

            console.log(myTrips);
            return myTrips;
        }   catch (error) {
            console.log(error);
        }
    }

async function handlePrint(e) {
        e.preventDefault();
        document.getElementById('printButton').addEventListener('click' , window.print());
    };


async function fetchTravels() {
    try {
        const response = await fetch("http://localhost:8000/travels", {
            method: "GET",
            headers: { "Content-Type": "application/json" },
        });
        
        if (!response.ok) {
            return null;
        }
        myTrips = await response.json();
        console.log(myTrips);
        updateUI(myTrips)
    }   catch (error) {
        console.log(error);
    }
}

export { handleSubmit, handleSave, handlePrint, fetchTravels };