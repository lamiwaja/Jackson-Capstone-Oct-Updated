import { handleSubmit, handlePrint, fetchTravels, handleSave } from './js/app.js';

//Import styles//
import "./styles/styles.scss";

alert("LOVE and UNITY FIRST");

document.addEventListener('DOMContentLoaded' , () => {
    window.addEventListener('load', fetchTravels);

    const form = document.getElementById('travelForms');
    form.addEventListener('submit' , handleSubmit);

    const save= document.getElementById('btnSave');
    save.addEventListener('click' , handleSave);
    
    document.getElementById('printButton').addEventListener('click' , handlePrint);

});