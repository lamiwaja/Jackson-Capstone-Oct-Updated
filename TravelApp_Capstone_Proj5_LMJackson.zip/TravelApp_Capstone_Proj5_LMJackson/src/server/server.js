var path = require('path');
const express = require ('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fetch = require('node-fetch');
const port = 8000;
const dotenv = require('dotenv');
dotenv.config();

// Start up an instance of app
const app = express();

//Here we are configuring express to use body-parser as middle-ware/
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

// Initialize the main project folder/
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('dist'))

// Spin up the server//
app.listen(port, listening);
function listening() {
    
    // console.log(server)
    console.log('server running');
    console.log(`running on localhost: ${port}`);

// Setup empty JS object as endpoint for all routes//

let travels = [];

//Set up GET Route//
app.get('/', function (req, res) {
    res.sendFile(path.resolve('dist/index.html'));
});

app.get('/travels', (req, res) => {
    res.status(200).send(travels);
});

//set up Post Route//

app.post('/travel/save', (req, res) => {
    const reqBody = req.body;
    
    console.log(reqBody.travel);

    if (!reqBody || !reqBody.travel) {
        return status(400).send("Invalid Response");
    }
    travels.push(reqBody.travel);

    res.status(200).send(travels);
});

}
// Setup Server//