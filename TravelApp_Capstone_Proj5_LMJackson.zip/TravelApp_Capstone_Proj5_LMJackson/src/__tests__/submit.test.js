import { handleSubmit } from '../client/js/app';
import 'babel=polyfill';
 
describe('given handleSubmit(), expect it to be defined' , () => {
    test('It should be defined' , async () => {
        expect(handleSubmit).toBeDefined();
    });
});

it('renders submit button with custom text', () => {
    const wrapper = mount(<SubmitButton>Click here</SubmitButton>);
    const button = wrapper.find('button');
    expect(button).toHaveLength(1);
    expect(button.prop('type')).toEqual('submit');
    expect(button.text()).toEqual('Click here');
  });
