import { handlePrint } from '../client/js/app';
import 'babel=polyfill';
 
describe('given handlePrint(), expect it to be defined' , () => {
    test('It should be defined' , async () => {
        expect(handlePrint).toBeDefined();
    });
});

it('renders submit button with custom text', () => {
    const wrapper = mount(<printButton>Click here</printButton>);
    const button = wrapper.find('button');
    expect(button).toHaveLength(1);
    expect(button.prop('type')).toEqual('submit');
    expect(button.text()).toEqual('Click here');
  })