CAPSTONE- Travel App Project
Introduction
This project builds out a travel app that, at a minimum, obtains a desired trip location & date from the user, and displays weather and an image of the location using information obtained from external APIs.  

The project will include a simple form where you enter the location you are traveling to and the date you are leaving. If the trip is within a week, you will get the current weather forecast. If the trip is in the future, you will get a projected forecast. The OpenWeather API is fantastic but it doesn’t let you get future data for free and it’s not that flexible with what information you enter; therefore we use the Weatherbit API to see how another API accomplishes the same goals. Weatherbit API has one problem, it only takes in coordinates for weather data -- it’s that specific. So, we’ll need to get those coordinates from the Geonames API. Once we have all of this data, we will display an image of the location entered; for this, we will be using the Pixabay API.

Server
To start the server run npm install, npm run start, then npm run build dev, lastly for production, use npm run build 
API's
1. Weatherbit
2. Geonames
3. Pixabay

API Keys
The API keys are not in the application. The Client folder inside the src folder has a directory called api. This folder holds the .json files for the various API's

Instructions
Geonames fetches the latitude, longitude, and country code information for a place entered by a user.

Weatherbit fetches the weather information by latitude and longitude fetched from Geonames

Pixabay provides a image, if avaialble, for the place the user would like to travel

To run the app, Run npm install, then start the node server using npm run start, next run the application in development mode using npm run dev. 

Finally, to build for Production, Run npm run build.